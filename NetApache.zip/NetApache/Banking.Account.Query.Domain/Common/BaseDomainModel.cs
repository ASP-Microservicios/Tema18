﻿namespace Banking.Account.Query.Domain.Common
{
    public abstract class BaseDomainModel
    {
       public int Id { get; set; }
    }
}
